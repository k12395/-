package com.bjpowernode.dao;

import com.bjpowernode.beans.ClassRoom;

import java.util.ArrayList;

public class ClassRoomDaoImp implements ClassRoomDaoIn{
    @Override
    public boolean add(ClassRoom classRoom) {
        return DB.classRooms.add(classRoom);
    }

    @Override
    public boolean del(ClassRoom classRoom) {
        return DB.classRooms.remove(classRoom);
    }

    @Override
    public boolean edit(ClassRoom classRoom) {
        return true;
    }

    @Override
    public ArrayList<ClassRoom> get() {
        return DB.classRooms;
    }



}
