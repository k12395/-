package com.bjpowernode.controller;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class ClassRoomAddController {
    @FXML
    private TextField tName;


}
