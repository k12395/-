package com.bjpowernode.services;

import com.bjpowernode.beans.ClassRoom;
import com.bjpowernode.exception.NameException;

import java.util.ArrayList;

public interface ClassRoomServicesIn {
    //增加班级
    boolean add(ClassRoom classRoom) throws NameException;
    //删除班级
    boolean del(ClassRoom classRoom);
    //修改班级
    Boolean edit(ClassRoom classRoom) throws NameException;
    //查询班级
    ArrayList<ClassRoom> getAll();
}
