package com.bjpowernode.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class StudentProController implements Initializable {

    @FXML
    private BorderPane borderPane;

    @FXML
    private Button btnStudentViewController;

    @FXML
    private Button btnClassRoomView;

    @FXML
    private Button btnExit;


    //todo 点击按钮显示班级界面
    @FXML
    void showClassRoomView(ActionEvent event) throws IOException {
        URL resource = StudentProController.class.getResource("/ClassRoomView.fxml");
        Node node = (Node)FXMLLoader.load(resource);
        //将节点资源放入中心区域
        borderPane.setCenter(node);

    }
    //todo 点击按钮显示学生界面
    @FXML
    void showStudentView(ActionEvent event) throws IOException {
        URL resource = StudentProController.class.getResource("/StudentView.fxml");
       Node node= (Node)FXMLLoader.load(resource);
      borderPane.setCenter(node);

    }
    //todo 点击按钮退出界面
    @FXML
    void exit(ActionEvent event) {
        System.exit(0);

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        URL resource = StudentProController.class.getResource("/ClassRoomView.fxml");
        Node node= null;
        try {
            node = (Node) FXMLLoader.load(resource);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        borderPane.setCenter(node);
    }
}
