package com.bjpowernode.controller;
import com.bjpowernode.beans.ClassRoom;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

public class StudentAddController {
    @FXML
    private TextField tName;

    @FXML
    private RadioButton rM;

    @FXML
    private ToggleGroup sex;

    @FXML
    private RadioButton rW;

    @FXML
    private TextField tAge;

    @FXML
    private TextField tScore;

    @FXML
    private ComboBox<ClassRoom> comBoxClassRoom;
}
