package com.bjpowernode.controller;

import com.bjpowernode.beans.ClassRoom;
import com.bjpowernode.exception.NameException;
import com.bjpowernode.services.ClassRoomServicesImp;
import com.bjpowernode.services.ClassRoomServicesIn;
import com.bjpowernode.services.StudentServicesImp;
import com.bjpowernode.services.StudentServicesIn;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import com.bjpowernode.controller.ClassRoomAddController;


import static com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;


public class ClassRoomViewController implements Initializable {
    //依赖业务
    ClassRoomServicesIn classRoomServicesIn = new ClassRoomServicesImp();
    StudentServicesIn studentServicesIn=new StudentServicesImp();

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnEdit;

    @FXML
    private Button btnDel;

    @FXML
    private TableView<ClassRoom> table;

    @FXML
    private TableColumn<ClassRoom, Integer> cId;

    @FXML
    private TableColumn<ClassRoom, String> cName;

    //todo 班级信息添加
    @FXML
    void add(ActionEvent event) throws IOException {
        //设置弹窗框面板
        DialogPane dialogPane = new DialogPane();
        URL resource = ClassRoomViewController.class.getResource("/ClassRoomAdd.fxml");
        Node node = (Node) FXMLLoader.load(resource);
        //使用node的lookup方法查询自己资源对象id,如果有则返回
        TextField tName = (TextField) node.lookup("#tName");
        //将设计好的fxml文件弹出来
        dialogPane.setGraphic(node);
        //设置底部按钮
        dialogPane.getButtonTypes().addAll(ButtonType.YES, ButtonType.NO);

        //设置弹出框架构
        Dialog<ButtonType> dialog = new Dialog<>();
        //将弹出框面板设置到dialog中去
        dialog.setDialogPane(dialogPane);
        //设置标题
        dialog.setTitle("班级信息添加");
        //弹出自定义文本框
        Optional<ButtonType> buttonType = dialog.showAndWait();
        //判断用户点击的是什么
        if (buttonType.get() == ButtonType.NO) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "班级信息添加失败", ButtonType.OK);
            alert.show();
            return;
        }
        ClassRoom classRoom = new ClassRoom();
        classRoom.setName(tName.getText());

        boolean add = false;
        try {
            add = classRoomServicesIn.add(classRoom);
        } catch (NameException e) {
            Alert alert=new Alert(Alert.AlertType.ERROR,e.getMessage(),ButtonType.CLOSE);
            alert.showAndWait();
        }
        if (!add) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "班级信息添加失败", ButtonType.CLOSE);
            alert.show();
            //程序终止
            return;
        }


        repair();


    }

    //todo 班级信息删除
    @FXML
    void del(ActionEvent event) {


        Alert alert = null;
        //获取选中模型
        TableView.TableViewSelectionModel<ClassRoom> selectionModel = table.getSelectionModel();
        //获取选中的班级对象
        ClassRoom selectedItem = selectionModel.getSelectedItem();
        //判断是否选中一行
        if (selectedItem == null) {
            alert = new Alert(Alert.AlertType.INFORMATION, "您还没有选中一行", ButtonType.CLOSE);
            alert.setTitle("删除班级信息");
            //让它弹出来
            alert.show();
            return;
        }
        //如果不为空，给予用户提示
        alert = new Alert(Alert.AlertType.INFORMATION, "是否真的删除", ButtonType.YES, ButtonType.NO);
        //获取用户选择对象
        Optional<ButtonType> buttonType = alert.showAndWait();
        if (buttonType.get() == ButtonType.NO) {
            return;
        }
        //开始真正的删除
        boolean del = classRoomServicesIn.del(selectedItem);

        for (int i = 0; i < studentServicesIn.getClassRoomNames().size(); i++) {
            if(selectedItem.getName().equals(studentServicesIn.getClassRoomNames().get(i))){
                alert=new Alert(Alert.AlertType.INFORMATION,"班级中存在学生信息，请先删除学生信息",ButtonType.CLOSE);
                alert.show();
                return;
            }
        }
        repair();

        //删除失败给予提示
        if (!del) {
            alert = new Alert(Alert.AlertType.INFORMATION, "删除失败", ButtonType.OK);
            alert.show();
            return;
        }
        //刷新表格
        repair();


    }

    //todo 班级信息修改
    @FXML
    void edit(ActionEvent event) throws IOException {
        Alert alert = null;
        classRoomServicesIn = new ClassRoomServicesImp();
        TableView.TableViewSelectionModel<ClassRoom> selectionModel = table.getSelectionModel();
        ClassRoom selectedItem = selectionModel.getSelectedItem();
        if (selectedItem == null) {
            alert = new Alert(Alert.AlertType.INFORMATION, "你还没有选中一行", ButtonType.CLOSE);
            alert.show();
            //程序终止
            return;
        }
        alert = new Alert(Alert.AlertType.INFORMATION, "是否真的修改", ButtonType.YES, ButtonType.NO);
        //获取用户选择对象
        Optional<ButtonType> buttonType = alert.showAndWait();
        if (buttonType.get() == ButtonType.NO) {
            alert = new Alert(Alert.AlertType.INFORMATION, "取消修改", ButtonType.CLOSE);
            alert.show();
            return;
        }
        DialogPane dialogPane = new DialogPane();
        URL resource = ClassRoomViewController.class.getResource("/ClassRoomAdd.fxml");
        Node node = (Node) FXMLLoader.load(resource);
        String name = selectedItem.getName();
        TextField tName = (TextField) node.lookup("#tName");
        tName.setText(name);

        dialogPane.setGraphic(node);
        dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("班级信息修改");
        dialog.setDialogPane(dialogPane);
        //获取用户选择对象
        Optional<ButtonType> buttonType1 = dialog.showAndWait();
        //判定用户选择的是什么
        if (buttonType1.get() == ButtonType.CANCEL) {
            alert = new Alert(Alert.AlertType.INFORMATION, "修改失败", ButtonType.CLOSE);
            alert.show();
            return;
        }
        //开始真正的修改
        selectedItem.setName(tName.getText());

        Boolean edit =false;
        try {
            edit = classRoomServicesIn.edit(selectedItem);
        } catch (NameException e) {
            alert=new Alert(Alert.AlertType.ERROR,e.getMessage(),ButtonType.CLOSE);
            alert.show();
        }
        if(!edit){
            alert=new Alert(Alert.AlertType.ERROR,"修改失败",ButtonType.CLOSE);
            alert.show();
            return;
        }

        repair();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        repair();
    }

    //表格刷新方法封装
    public void repair() {
        table.getItems().clear();
        //绑定列
        cId.setCellValueFactory(new PropertyValueFactory<ClassRoom, Integer>("id"));
        cName.setCellValueFactory(new PropertyValueFactory<ClassRoom, String>("name"));
        //拿到业务的数据
        ArrayList<ClassRoom> all = classRoomServicesIn.getAll();
        ObservableList<ClassRoom> classRooms = FXCollections.observableArrayList(all);
        table.setItems(classRooms);

    }


}
