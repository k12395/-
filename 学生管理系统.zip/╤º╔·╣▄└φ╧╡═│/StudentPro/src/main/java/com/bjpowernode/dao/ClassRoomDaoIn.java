package com.bjpowernode.dao;

import com.bjpowernode.beans.ClassRoom;

import java.util.ArrayList;

public interface ClassRoomDaoIn {
    //增加班级;
    boolean add(ClassRoom classRoom);
    //删除班级
    boolean del(ClassRoom classRoom);
    //修改班级
    boolean edit(ClassRoom classRoom);
    //查询班级
   ArrayList<ClassRoom> get();


}
