package com.bjpowernode.dao;

import com.bjpowernode.beans.Student;

import java.util.ArrayList;

public interface StudentDaoIn {
    //增加学生
    boolean add(Student student);
    //删除学生
    boolean del(Student student);
    //修改学生
    boolean edit(Student student);
    //查询学生
    ArrayList<Student> getAll();
}
