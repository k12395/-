package com.bjpowernode.app;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class MyApp extends Application {
    public static void main(String[] args) {
Application.launch();
     }

    @Override
    public void start(Stage primaryStage) throws Exception {

        //根容器里面设置按钮，组件
        Parent parent=null;
        //获取资源并将资源放进去
        URL resource = MyApp.class.getResource("/stuPro.fxml");
        parent = (Parent)FXMLLoader.load(resource);
        //主窗口上面设置根容器
        Scene scene=new Scene(parent);
        //设置主窗口上面的场景
        primaryStage.setScene(scene);
        //设置主窗口标题
        primaryStage.setTitle("学生管理系统");

        //让它展示出来
        primaryStage.show();
    }
}
