package com.bjpowernode.exception;

public class NameException extends Exception{
    public NameException(String message) {
        super(message);
    }
}
