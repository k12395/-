package com.bjpowernode.dao;

import com.bjpowernode.beans.ClassRoom;
import com.bjpowernode.beans.Student;

import java.util.ArrayList;

public class DB {
    public static ArrayList<ClassRoom> classRooms = new ArrayList<>();
    public static ArrayList<Student> students = new ArrayList<>();

    //初始化班级和学生信息，并增加到集合中去；
    static {
        classRooms.add(new ClassRoom(1000, "sz2207"));
        classRooms.add(new ClassRoom(1001, "sz2208"));
        classRooms.add(new ClassRoom(1002, "sz2209"));
        classRooms.add(new ClassRoom(1003, "sz2210"));
        classRooms.add(new ClassRoom(1004, "sz2211"));
    }

    static {
        students.add(new Student(1101, "name1", 23, "女", 89, classRooms.get(0)));
        students.add(new Student(1102, "name2", 23, "女", 79, classRooms.get(0)));
        students.add(new Student(1103, "name3", 23, "女", 78, classRooms.get(1)));
        students.add(new Student(1104, "name4", 23, "女", 88, classRooms.get(1)));
        students.add(new Student(1105, "name5", 23, "女", 91, classRooms.get(2)));
    }


}




