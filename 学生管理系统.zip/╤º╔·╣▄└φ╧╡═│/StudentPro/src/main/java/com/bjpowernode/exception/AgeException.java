package com.bjpowernode.exception;

public class AgeException extends Exception{
    public AgeException(String message) {
        super(message);
    }
}
