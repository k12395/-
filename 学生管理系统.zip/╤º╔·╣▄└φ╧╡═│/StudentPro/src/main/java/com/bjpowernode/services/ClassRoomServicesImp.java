package com.bjpowernode.services;

import com.bjpowernode.beans.ClassRoom;
import com.bjpowernode.dao.ClassRoomDaoImp;
import com.bjpowernode.dao.ClassRoomDaoIn;
import com.bjpowernode.dao.DB;
import com.bjpowernode.exception.NameException;

import java.util.ArrayList;
import java.util.LinkedList;

import static com.bjpowernode.dao.DB.classRooms;
import static com.bjpowernode.dao.DB.students;

public class ClassRoomServicesImp implements ClassRoomServicesIn{
StudentServicesIn studentServicesIn=new StudentServicesImp();

    private static LinkedList<Integer> integers=new LinkedList<>();
    static{
        for (int i = 1005; i <=5000; i++) {
            integers.add(i);
        }
    }
    ClassRoomDaoIn classRoomDaoIn=new ClassRoomDaoImp();
    @Override
    public boolean add(ClassRoom classRoom) throws NameException {
        if(classRoom.getName().length() < 4 || classRoom.getName().length() > 10){
            throw new NameException("名称长度不合法");
        }
        Integer id = integers.pollFirst();
        classRoom.setId(id);
        return classRoomDaoIn.add(classRoom);
    }

    @Override
    public boolean del(ClassRoom classRoom) {
        int id = classRoom.getId();

        boolean contains = studentServicesIn.getClassRoomNames().contains(classRoom.getName());
        //如果contains为真，则代表有学生使用了这个班级，不能删除。
        if(contains){
            return false;
        }
        integers.offerFirst(id);
        boolean del = classRoomDaoIn.del(classRoom);
        return del;
    }

    @Override
    public Boolean edit(ClassRoom classRoom) throws NameException {
        if(classRoom.getName().length() < 4 || classRoom.getName().length() > 10){
            throw new NameException("名称长度不合法");
        }
        return classRoomDaoIn.edit(classRoom);
    }

    @Override
    public ArrayList<ClassRoom> getAll() {
        return classRoomDaoIn.get();
    }
}
