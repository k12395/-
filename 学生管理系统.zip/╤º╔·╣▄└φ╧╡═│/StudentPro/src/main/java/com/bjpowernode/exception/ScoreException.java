package com.bjpowernode.exception;

public class ScoreException extends Exception{
    public ScoreException(String message) {
        super(message);
    }
}
