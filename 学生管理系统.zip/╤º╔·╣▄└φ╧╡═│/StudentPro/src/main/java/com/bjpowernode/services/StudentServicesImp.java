package com.bjpowernode.services;

import com.bjpowernode.beans.Student;
import com.bjpowernode.controller.StudentViewController;
import com.bjpowernode.dao.DB;
import com.bjpowernode.dao.StudentDaoImp;
import com.bjpowernode.dao.StudentDaoIn;
import com.bjpowernode.exception.AgeException;
import com.bjpowernode.exception.NameException;
import com.bjpowernode.exception.ScoreException;

import java.util.*;

import static com.bjpowernode.dao.DB.classRooms;

public class StudentServicesImp implements StudentServicesIn {
    StudentDaoIn studentDaoIn = new StudentDaoImp();

    private static ArrayList<String> classRoomNames = new ArrayList<>();

    static {
        classRoomNames.add(classRooms.get(0).getName());
        classRoomNames.add(classRooms.get(0).getName());
        classRoomNames.add(classRooms.get(1).getName());
        classRoomNames.add(classRooms.get(1).getName());
        classRoomNames.add(classRooms.get(2).getName());
    }

    private static LinkedList<Integer> integers = new LinkedList<>();

    static {
        for (int i = 1006; i < 5000; i++) {
            integers.add(i);
        }
    }

    @Override
    public boolean add(Student student) throws AgeException, ScoreException, NameException {
        if(student.getAge() < 10 || student.getAge() > 100){
            throw new AgeException("学生年龄不合法");
        }
        if(student.getScore() <0|| student.getScore()>150){
            throw new ScoreException("学生分数不合法");
        }
        if(student.getName().length()<2 || student.getName().length()>10){
            throw new NameException("学生姓名不合法");
        }
        Integer id = integers.pollFirst();
        student.setId(id);
        classRoomNames.add(student.getClassRoom().getName());
        return studentDaoIn.add(student);
    }

    @Override
    public boolean del(Student student) {
        integers.offerFirst(student.getId());
        classRoomNames.remove(student.getClassRoom().getName());

        return studentDaoIn.del(student);
    }

    @Override
    public boolean edit(Student student) throws AgeException, ScoreException, NameException {
        if(student.getAge() < 10 || student.getAge() > 100){
            throw new AgeException("学生年龄不合法");
        }
        if(student.getScore() <0|| student.getScore()>150){
            throw new ScoreException("学生分数不合法");
        }
        if(student.getName().length()<2 || student.getName().length()>10){
            throw new NameException("学生姓名不合法");
        }
        return studentDaoIn.edit(student);
    }

    @Override
    public ArrayList<Student> getAll() {
        return studentDaoIn.getAll();
    }

    @Override
    public ArrayList<String> getClassRoomNames() {
        return classRoomNames;
    }

    @Override
    public ArrayList<Student> Call(int number) {
        ArrayList<Student> all = getAll();
        HashSet<Integer> indexs = new HashSet<>();
        Random random = new Random();
        loop:
        while (true) {
            int nextInt = random.nextInt(all.size());
            indexs.add(nextInt);
            if (indexs.size() == number) {
                break loop;
            }
        }
        //排序
        //把HashSet的下标集合转换成
        ArrayList<Integer> arrayListTemp = new ArrayList<>(indexs);
        //下标排序
        Collections.sort(arrayListTemp);
        //创建返回集合
        ArrayList<Student> resultStudent = new ArrayList<>();
        //循环下表，从全集里面抽出学生放到子集里面
        for (Integer index : arrayListTemp) {
            resultStudent.add(all.get(index));

        }

        return resultStudent;
    }
}
