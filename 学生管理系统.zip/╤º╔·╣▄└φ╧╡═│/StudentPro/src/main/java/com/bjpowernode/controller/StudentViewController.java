package com.bjpowernode.controller;

import com.bjpowernode.beans.ClassRoom;
import com.bjpowernode.beans.Student;
import com.bjpowernode.exception.AgeException;
import com.bjpowernode.exception.NameException;
import com.bjpowernode.exception.ScoreException;
import com.bjpowernode.services.ClassRoomServicesImp;
import com.bjpowernode.services.ClassRoomServicesIn;
import com.bjpowernode.services.StudentServicesImp;
import com.bjpowernode.services.StudentServicesIn;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Optional;
import java.util.ResourceBundle;

public class StudentViewController implements Initializable {
    //依赖业务
    StudentServicesIn studentServicesIn = new StudentServicesImp();
    ClassRoomServicesIn classRoomServicesIn = new ClassRoomServicesImp();
    @FXML
    private Button btnAdd;

    @FXML
    private Button btnDel;

    @FXML
    private Button btnEdit;

    @FXML
    private Button btnCall;

    @FXML
    private TextField tNumber;


    @FXML
    private TableView<Student> table;

    @FXML
    private TableColumn<Student, Integer> cId;

    @FXML
    private TableColumn<Student, String> cName;

    @FXML
    private TableColumn<Student, String> cSex;

    @FXML
    private TableColumn<Student, Integer> cAge;

    @FXML
    private TableColumn<Student, Float> cScore;

    @FXML
    private TableColumn<Student, ClassRoom> cClassroom;

    //todo 学生信息添加
    @FXML
    void add(ActionEvent event) throws IOException {
        DialogPane dialogPane = new DialogPane();
        //绑定资源
        URL resource = StudentViewController.class.getResource("/StudentAdd.fxml");
        //转为node节点
        Node node = (Node) FXMLLoader.load(resource);
        //列绑定
        TextField tName = (TextField) node.lookup("#tName");
        RadioButton rM = (RadioButton) node.lookup("#rM");
        RadioButton rW = (RadioButton) node.lookup("#rW");
        TextField tAge = (TextField) node.lookup("#tAge");
        TextField tScore = (TextField) node.lookup("#tScore");
        ComboBox<ClassRoom> comboBoxClassRoom = (ComboBox<ClassRoom>) node.lookup("#comBoxClassRoom");
        dialogPane.setGraphic(node);
        //填充ComBox里面的信息
        ArrayList<ClassRoom> all = classRoomServicesIn.getAll();
        ObservableList<ClassRoom> classRooms = FXCollections.observableArrayList(all);
        //清空所有数据
        comboBoxClassRoom.getItems().clear();
        //填充数据
        comboBoxClassRoom.setItems(classRooms);
        //默认选择第一个
        SingleSelectionModel<ClassRoom> selectionModel = comboBoxClassRoom.getSelectionModel();
        selectionModel.selectFirst();
        //设置底部按钮
        dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);


        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setDialogPane(dialogPane);
        dialog.setTitle("学生信息添加");
        //判定学生点击对象
        Optional<ButtonType> buttonType = dialog.showAndWait();
        if (buttonType.get() == ButtonType.CANCEL) {
            //程序终止
            return;
        }
        //开始添加
        Student student = new Student();
        //添加学生信息
        student.setName(tName.getText());
        student.setSex(rM.isSelected() ? "男" : "女");
        student.setAge(Integer.parseInt(tAge.getText()));
        student.setScore(Float.parseFloat(tScore.getText()));
        student.setClassRoom(selectionModel.getSelectedItem());
        //将学生信息添加到DB中去
        boolean add = false;
        Alert alert=null;
        try {
            add = studentServicesIn.add(student);
        } catch (AgeException e) {
            alert=new Alert(Alert.AlertType.ERROR,e.getMessage(),ButtonType.CLOSE);
            alert.show();
        } catch (ScoreException e) {
            alert=new Alert(Alert.AlertType.ERROR,e.getMessage(),ButtonType.CLOSE);
            alert.show();
        } catch (NameException e) {
           alert=new Alert(Alert.AlertType.ERROR,e.getMessage(),ButtonType.CLOSE);
           alert.show();
        }
        //判定是否添加成功，添加失败给与用户提示
        if (!add) {
             alert = new Alert(Alert.AlertType.INFORMATION, "学生信息添加失败", ButtonType.CLOSE);
            alert.show();
            //程序终止
            return;
        }
        repair();


    }

    //todo 学生信息删除
    @FXML
    void del(ActionEvent event) {
        //获取选中的模型对象
        TableView.TableViewSelectionModel<Student> selectionModel = table.getSelectionModel();
        //获取选中的学生对象
        Student selectedItem = selectionModel.getSelectedItem();
        Alert alert = null;
        if (selectedItem == null) {
            alert = new Alert(Alert.AlertType.INFORMATION, "你还没有选择一行", ButtonType.CLOSE);
            alert.show();
            return;
        }
        //如果不为空，则给予用户提示
        alert = new Alert(Alert.AlertType.INFORMATION, "是否真的删除", ButtonType.YES, ButtonType.NO);
        //获取用户选择的对象
        Optional<ButtonType> buttonType = alert.showAndWait();
        //判定用户选择对象
        if (buttonType.get() == ButtonType.NO) {
            //程序终止
            return;
        }
        //开始真正的删除
        boolean del = studentServicesIn.del(selectedItem);
        if (!del) {
            alert = new Alert(Alert.AlertType.INFORMATION, "删除失败", ButtonType.CLOSE);
            alert.show();
            return;
        }
        repair();


    }

    //todo 学生信息修改
    @FXML
    void edit(ActionEvent event) throws IOException {
        Student selectedItemStudent = table.getSelectionModel().getSelectedItem();
        DialogPane dialogPane = new DialogPane();
        URL resource = StudentViewController.class.getResource("/StudentAdd.fxml");
        Node node = (Node) FXMLLoader.load(resource);
        TextField tName = (TextField) node.lookup("#tName");
        tName.setText(selectedItemStudent.getName());
        RadioButton rM = (RadioButton) node.lookup("#rM");
        RadioButton rW = (RadioButton) node.lookup("#rW");
        if (selectedItemStudent.getSex().equals("rM")) {
            rM.setSelected(true);
        } else {
            rW.setSelected(true);
        }
        TextField tAge = (TextField) node.lookup("#tAge");
        tAge.setText(String.valueOf(selectedItemStudent.getAge()));
        TextField tScore = (TextField) node.lookup("#tScore");
        tScore.setText(String.valueOf(selectedItemStudent.getScore()));
        ComboBox<ClassRoom> comboBoxClassRoom = (ComboBox<ClassRoom>) node.lookup("#comBoxClassRoom");

        dialogPane.setGraphic(node);

        //填充ComBox里面的信息
        ArrayList<ClassRoom> all = classRoomServicesIn.getAll();
        ObservableList<ClassRoom> classRooms = FXCollections.observableArrayList(all);
        //清空所有数据
        comboBoxClassRoom.getItems().clear();
        //填充数据
        comboBoxClassRoom.setItems(classRooms);
        //默认选择第一个
        SingleSelectionModel<ClassRoom> selectionModelClassRoom = comboBoxClassRoom.getSelectionModel();
        ClassRoom classRoom = selectedItemStudent.getClassRoom();
        selectionModelClassRoom.select(classRoom);
        //设置底部按钮
        dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);


        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setDialogPane(dialogPane);
        dialog.setTitle("学生信息修改");


        if (selectedItemStudent == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "你还没有选中一行", ButtonType.CLOSE);
            alert.show();
            return;
        }

        //判定学生点击对象
        Optional<ButtonType> buttonType = dialog.showAndWait();
        if (buttonType.get() == ButtonType.CANCEL) {
            //程序终止
            return;
        }
        //开始修改
        selectedItemStudent.setName(tName.getText());
        selectedItemStudent.setSex(rM.isSelected() ? "男" : "女");
        selectedItemStudent.setScore(Float.parseFloat(tScore.getText()));
        selectedItemStudent.setClassRoom(comboBoxClassRoom.getSelectionModel().getSelectedItem());
        selectedItemStudent.setAge(Integer.parseInt(tAge.getText()));
        boolean edit = false;
        Alert alert=null;
        try {
            edit = studentServicesIn.edit(selectedItemStudent);
        } catch (AgeException e) {
            alert=new Alert(Alert.AlertType.ERROR,e.getMessage(),ButtonType.CLOSE);
            alert.showAndWait();
        } catch (ScoreException e) {
            alert=new Alert(Alert.AlertType.ERROR,e.getMessage(),ButtonType.CLOSE);
            alert.showAndWait();
        } catch (NameException e) {
            alert=new Alert(Alert.AlertType.ERROR,e.getMessage(),ButtonType.CLOSE);
            alert.showAndWait();
        }
        if(!edit){
            alert=new Alert(Alert.AlertType.ERROR,"修改失败",ButtonType.CLOSE);
            alert.show();
        }

        repair();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        //绑定列
        cId.setCellValueFactory(new PropertyValueFactory<Student, Integer>("id"));
        cName.setCellValueFactory(new PropertyValueFactory<Student, String>("name"));
        cAge.setCellValueFactory(new PropertyValueFactory<Student, Integer>("age"));
        cSex.setCellValueFactory(new PropertyValueFactory<Student, String>("sex"));
        cScore.setCellValueFactory(new PropertyValueFactory<Student, Float>("score"));
        cClassroom.setCellValueFactory(new PropertyValueFactory<Student, ClassRoom>("classRoom"));


        repair();

    }

    //todo 学生信息初始化
    private void repair() {
        table.getItems().clear();
        ArrayList<Student> all = studentServicesIn.getAll();
        ObservableList<Student> students = FXCollections.observableArrayList(all);
        table.setItems(students);
    }

    @FXML
    void call(ActionEvent event) {
        //点名人数
        int number=Integer.parseInt(tNumber.getText());
        //业务返回点名学生的集合
        ArrayList<Student> call = studentServicesIn.Call(number);
        //字符串累加
        StringBuilder stringBuilder=new StringBuilder();
        for (Student student : call) {
            stringBuilder.append(student.getId());
            stringBuilder.append(":");
            stringBuilder.append(student.getName());
            stringBuilder.append("\n");
        }
        String s ="回答问题的学生是"+"\n"+stringBuilder.toString();
        Alert alert=new Alert(Alert.AlertType.INFORMATION,s,ButtonType.CLOSE);
        alert.show();

    }

}

