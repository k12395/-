package com.bjpowernode.dao;

import com.bjpowernode.beans.Student;

import java.util.ArrayList;

public class StudentDaoImp implements StudentDaoIn{
    @Override
    public boolean add(Student student) {
        return DB.students.add(student);
    }

    @Override
    public boolean del(Student student) {
        return DB.students.remove(student);
    }

    @Override
    public boolean edit(Student student) {
        return true;
    }

    @Override
    public ArrayList<Student> getAll() {
        return DB.students;
    }
}
