package com.bjpowernode.services;

import com.bjpowernode.beans.Student;
import com.bjpowernode.exception.AgeException;
import com.bjpowernode.exception.NameException;
import com.bjpowernode.exception.ScoreException;

import java.util.ArrayList;
import java.util.HashSet;

public interface StudentServicesIn {
    //增加学生
    boolean add(Student student) throws AgeException, ScoreException, NameException;
    //删除学生
    boolean del(Student student);
    //修改学生
    boolean edit(Student student) throws AgeException, ScoreException, NameException;
    //查询学生
    ArrayList<Student> getAll();

    ArrayList<String> getClassRoomNames();

    ArrayList<Student> Call(int number);
}
